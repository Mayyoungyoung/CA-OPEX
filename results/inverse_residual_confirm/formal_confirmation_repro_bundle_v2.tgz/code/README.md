# Reward-noise mechanism audit

This directory contains a clean-room mechanism audit for testing whether a
trajectory score is robust to stochastic rewards.  It does not import or copy
the HUBL supplementary implementation.

`mechanism_audit.py` reads the standard flat D4RL HDF5 fields
`observations`, `actions`, `rewards`, `terminals`, and `timeouts`, reconstructs
complete trajectories, and injects seeded additive reward noise.  A small
heteroscedastic MLP predicts the time-zero return-to-go from reward-free
trajectory descriptors.  Every prediction is strictly out-of-fold at the
trajectory level; normalization is also trained only on the non-held-out
folds.  Within each outer training split, a disjoint calibration subset learns
a single uncertainty scale; it never sees the outer test trajectories or the
latent clean returns.  This guards against neural variance collapse while
preserving strict out-of-fold evaluation.  The same inner split selects an
early-stopped checkpoint by noisy-target NLL and then estimates a scalar
uncertainty correction; neither operation uses latent clean returns.

The saved `audit_arrays.npz` contains clean/noisy per-transition rewards, the
realized injected noise, latent clean trajectory returns, fold assignments,
raw noisy returns, cross-fitted mean/std, and the LCB score.  The JSON record
contains dataset SHA-256, all seeds and hyperparameters, exact train/test
trajectory ids per fold, wall time, ranking metrics, MSE, and uncertainty
coverage against the latent clean return.

Quick synthetic integration run:

```bash
python mechanism_audit.py make-synthetic \
  --output results/synthetic/source.hdf5 --trajectories 160 --seed 17
python mechanism_audit.py audit \
  --dataset results/synthetic/source.hdf5 \
  --output-dir results/synthetic/audit \
  --noise-std 3 --noise-seed 20260914 \
  --folds 5 --fold-seed 31 --model-seed 47 \
  --target-source noisy --epochs 300 --device cpu
pytest -q tests/test_mechanism.py
```

For a public D4RL file, replace `--dataset`.  `--target-source noisy` is the
deployable setting; `clean` is provided only as an oracle audit control.  This
module measures the proposed scoring mechanism and is not itself an offline-RL
performance result.

The checked-in synthetic record at
`results/synthetic/audit_final/audit_metrics.json` used 160 trajectories,
five outer folds, and Gaussian reward noise with per-transition standard
deviation 3.  On the server GPU, the raw noisy-return / OOF-mean results were:
MSE 65.95 / 8.54, Spearman 0.656 / 0.966, and top-20% precision 0.531 / 0.875.
The LCB score was worse than the mean-only score on this construction, so the
record supports cross-fitted denoising but does not by itself support a
risk-adjusted ranking claim.

## Episode-fold Q/V predictor for CA-HUBL

`qv_predictor.py` fits two return regressors on every non-held-out episode
fold: `V(s) -> G_t` and `Q(s,a) -> G_t`.  Their targets are discounted returns
computed from the seeded noisy rewards; clean returns are saved only for
auditing.  Observation, action, and target normalization statistics are
computed anew from each outer training fold.  Predictions for an episode are
therefore always produced by models that did not train on any transition from
that episode.

The transition convention exactly matches `train_iql.py` for flat D4RL files:
episodes are split on `terminal | timeout`; the final true-terminal row is
kept, whereas the final timeout or incomplete row is dropped.  The NPZ stores
the original HDF5 row of every kept transition and a SHA-256 digest over the
ordered `(observation, action, next observation, episode id, row id)` tuple.
`crossfit_next_mean` is the out-of-fold `V(next_state)` in raw reward units and
can be consumed directly by the `*_h` IQL variants.  At episode level,
`crossfit_mean` averages this denoised next-state value, while
`controllable_score` averages `Q(s,a)-V(s)` to isolate action-dependent return
quality from state visitation quality.  With more than one ensemble member,
the corresponding `*_std` arrays are trajectory-bootstrap epistemic proxies.

Fast deterministic integration check (linear regressors):

```bash
python qv_predictor.py \
  --dataset /path/to/walker2d_medium-v2.hdf5 \
  --output results/walker/qv_ridge.npz \
  --backend ridge --folds 5 --ensemble-size 3 \
  --iid-noise-scale 1 --episode-noise-scale 1
pytest -q tests/test_qv_predictor.py
```

GPU MLP run with the same data contract:

```bash
python qv_predictor.py \
  --dataset /path/to/walker2d_medium-v2.hdf5 \
  --output results/walker/qv_mlp.npz \
  --backend mlp --device cuda --folds 5 --ensemble-size 3 \
  --train-steps 3000 --batch-size 1024 \
  --iid-noise-scale 1 --episode-noise-scale 1
```

Each run also writes a JSON sidecar containing the archive checksum, dataset
checksum, exact train/held-out episode ids, fold-local normalization hashes,
all seeds and hyperparameters, and measured wall time.  The ensemble spread is
not calibrated aleatoric uncertainty; it is deliberately labeled as an
epistemic proxy.

## Clean-room IQL/HUBL training harness

`iql_core.py` and `train_iql.py` implement an equal-budget IQL comparison
without importing the unlicensed HUBL supplement.  The loader accepts both the
original flat D4RL HDF5 schema and episodic Minari conversions, reconstructs
the exact trajectory-level HUBL rank, discards timeout-final transitions as in
the D4RL q-learning protocol, and records the source SHA-256, noise realization,
configuration, raw progress, checkpoints, and every evaluation episode.

Available controls are base IQL, constant HUBL, realized-return rank HUBL,
cross-fitted point-estimate rank, LCB rank, and posterior-expected rank.  The
`*_h` variants additionally require an aligned out-of-fold next-state value
array and replace the noisy Monte-Carlo heuristic itself.  Posterior-expected
rank uses

```text
rho_i = mean_{j != i} Phi((mu_i-mu_j) / sqrt(sigma_i^2+sigma_j^2)),
lambda_i = alpha * rho_i.
```

This shrinks uncertain extreme ranks toward the middle; it is distinct from a
risk-sensitive `mu-kappa*sigma` lower quantile.  It remains an experimental
control until it beats both mean-only and constant HUBL.

Server smoke command (actually run against the official one-million-transition
Walker2d-medium-v2 file):

```bash
python train_iql.py \
  --dataset /root/hubl_backup_data/walker2d_medium-v2.hdf5 \
  --output-dir /root/hubl_research_20260914/results/smoke_iql \
  --variant iql --max-episodes 10 --updates 20 \
  --batch-size 32 --hidden-dim 64 --eval-period 20 \
  --eval-episodes 1 --device cuda
```

Full comparison runs use the same data/noise seed and evaluation episode seeds
for every variant.  Reward-noise experiments specify the standard deviation in
units of the clean per-transition reward standard deviation with
`--iid-noise-scale`; they are a controlled corruption protocol and must not be
described as HUBL's action-noise Walker2d protocol.

## Action-noise counterfactual replay audit

`counterfactual_audit.py` consumes the flat HDF5 written by
`collect_stochastic.py`.  For each episode it resets `Walker2d-v4` to the exact
logged initial `infos/qpos` and `infos/qvel`, then performs two deterministic
replays.  The first uses the logged executed actions and checks stored rewards
and next observations.  The second substitutes that trajectory's stored
`clean_policy_actions` open loop.  The first replay is a validity check; the
second return is a mechanism-audit label for how this particular action
sequence changes when injected action noise is removed.

Importantly, the clean-action replay is not a behavior-policy expected return
and not a closed-loop policy evaluation.  It does not recompute policy actions
at the counterfactual states, and it stops if the counterfactual Walker episode
ends before the logged horizon.

```bash
python counterfactual_audit.py \
  --dataset /path/to/walker_action_noise.hdf5 \
  --output results/walker_action_noise/counterfactual_audit.json \
  --max-episodes 10 --strict
pytest -q tests/test_counterfactual_audit.py
```

The JSON contains the source-file SHA-256, per-episode noisy and clean-action
returns, episode lengths, replay errors, early terminations, tolerances, and an
aggregate pass/fail flag.  `--strict` writes the complete record before exiting
non-zero when logged action replay fails.

Development result (not confirmation):
`results/action_noise_dev/counterfactual_audit_256ep.json` audits the first 256
episodes without outcome-based filtering (79,639 transitions, 7.96% of the
dataset).  Logged-action replay passed for all 256 episodes, with worst reward
and next-observation absolute errors of `2.39e-7` and `4.77e-7`.  In contrast,
the clean-action open-loop replay ended early for 251/256 episodes; its return
had approximately 0.096 Pearson and 0.029 Spearman correlation with logged
return.  We therefore reject this open-loop return as a usable policy-quality
or counterfactual-return label.  The replay validator and raw measurements are
reusable, but this failed label must not be used to tune or support the method.

## Dual-action TD3+BC controls

`train_td3bc.py` keeps the stochastic collector's `actions` (executed actuator
input) and `clean_policy_actions` (behavior-policy command) as distinct batch
fields. `--action-pairing` selects one equal-budget control:

- `executed_executed`: standard TD3+BC, with executed actions for critic
  regression and actor behavior cloning;
- `commanded_commanded`: naive relabeling, with commanded actions for both;
- `executed_commanded`: executed actions for the critic and commands for BC.

The latter is a mechanism/protocol ablation, not currently claimed as a novel
method: commanded/executed action distinctions already appear in the MAMDP
literature. All three settings leave reward preprocessing, network size, and
update budget unchanged. Each scheduled evaluation runs both a clean policy
rollout and a persistent actuator-noise rollout; the latter adds independently
seeded `Uniform[-beta,beta]` noise to every command before clipping, with
`--eval-action-noise-beta 1` by default. Episode environment and noise seeds
are written to `progress.jsonl` and `summary.json`.

```bash
python train_td3bc.py \
  --dataset /path/to/walker2d_v4_beta1.hdf5 \
  --output-dir results/dual_action/executed_commanded \
  --variant td3bc --action-pairing executed_commanded \
  --eval-action-noise-beta 1 --eval-seed 9000 --eval-noise-seed 19000
pytest -q tests/test_td3bc.py
```

## Episode-OOF action-noise Q/V audit

`action_qv_audit.py` joins the stochastic Walker HDF5 with a prediction archive
from `qv_predictor.py`. It verifies the dataset checksum, exact retained-row
order, episode ids, lengths, and saved action deltas before writing
`episode_metrics.csv`. `audit_metrics.json` deterministically derives the full
signal/target correlation grid, top/bottom-quintile tables, deciles, top-set
overlap, and a seeded paired episode bootstrap against raw HUBL ranking. An
optional `counterfactual_audit.py` JSON is joined by episode id; its open-loop
return remains labelled as a mechanism diagnostic, not expected policy return.

```bash
python action_qv_audit.py \
  --dataset /path/to/walker2d_v4_beta1.hdf5 \
  --predictions results/action_qv_audit/qv_predictions.npz \
  --counterfactual results/action_noise_dev/counterfactual_audit_256ep.json \
  --output-dir results/action_qv_audit/analysis \
  --bootstrap-replicates 500
```

The 2026-09-14 development records under `results/action_qv_audit/` cover all
3,255 episodes for both a 5-fold, 3-member ridge predictor and a 5-fold,
single-member 128-wide MLP. They are mechanism-screening runs, not frozen
offline-RL confirmation results.

## Inverse-residual result aggregation

`aggregate_inverse_residual_results.py` consumes only manifest-referenced raw
adapter evaluation and frozen-Q audit JSONs. It writes deterministic JSON, CSV,
and Markdown summaries with per-training-seed values and fixed-checkpoint paired
episode intervals. `inverse_residual_pre_split_dev_manifest.json` labels all
existing adapter evidence as development and retains the failed pre-update
launches. `inverse_residual_frozen_confirmation_manifest.template.json`
uses the fail-closed `inverse-residual-manifest-v2` schema. It predeclares seeds
1/10 for five controls: inverse/sampled, direct/sampled, inverse/Q-at-channel-
mean, wide direct/sampled, and nominal-Q beta-zero direct/sampled. The wide
controls explicitly match `penalty / delta_max^2 = 0.16` and
`learning_rate * delta_max = 7.5e-5`. Every run locks the exact training config,
dataset/base/calibration hashes, split hashes, evaluation seed arrays, independent
K=64 audit protocol at physical beta 1.25, checkpoint format/linkage, and actual
train/core/evaluate/audit implementation hashes. Every paired comparison also
requires the same training seed and base-checkpoint hash. The legacy development
manifest remains readable but is labeled `legacy_v1_not_fail_closed`.

The template deliberately contains implementation-hash placeholders for the
seven adapter files plus the OPEX evaluator and TD3+BC trainer, and cannot be
aggregated. Freeze it exactly once, after code and
input artifacts are final but before any of its ten output directories exists:

```bash
python aggregate_inverse_residual_results.py \
  --freeze-template inverse_residual_frozen_confirmation_manifest.template.json \
  --frozen-manifest inverse_residual_frozen_confirmation_manifest.json \
  --implementation-root /root/hubl_research_20260914/code \
  --freeze-artifact /root/hubl_backup_data/action_noise_dev/walker2d_v4_beta1_seed1201.hdf5 \
  --freeze-artifact /path/to/n512_channel_calibration.json \
  --freeze-artifact /root/hubl_research_20260914/results/inverse_residual_confirm/base_hubl_executed_25k_seed1/latest.pt \
  --freeze-artifact /root/hubl_research_20260914/results/inverse_residual_confirm/base_hubl_executed_25k_seed10/latest.pt
```

The freeze mode computes hashes from those files, requires their hash set to
equal the predeclared dataset/base/calibration set, independently recomputes the
whole-episode train/audit split (including all three index hashes), verifies all
output directories are absent, and atomically creates a new manifest without overwrite.
This `aggregate_inverse_residual_results.py --freeze-template ...` mode is the
canonical freezer. Strict aggregation inventories each runner-created sibling
`<training_dir>.train.console.log`; only legacy manifests may fall back to the
older in-directory `launch.log` layout.
After every predeclared raw file is complete, aggregate with:

```bash
python aggregate_inverse_residual_results.py \
  --manifest inverse_residual_frozen_confirmation_manifest.json \
  --output-dir results/inverse_residual_confirm/aggregate \
  --stem frozen_confirmation
```

Audit output records both the checkpoint model/calibration beta and the actual
audit beta. Frozen audits must pass `--audit-action-noise-beta 1.25`; this is
essential for the nominal-Q beta-zero training control. Audit JSON/CSV/Markdown
retain means and medians for Q1, Q2, min-twin, and twin-disagreement diagnostics.
Adapter training cost is split into base-actor precompute rows, Q-scale Q1
forward rows, optimizer Q1 forward/backward rows, adapter-MLP forward/backward
rows, and total Q1 forward rows. Adapter rollout cost derives each arm's base-
actor and adapter-MLP rows exactly from raw episode lengths; only paired-total
wall time is available, so no per-arm wall time is imputed. Every resume
invocation recomputes the base commands and Q-scale calibration, so the
aggregator multiplies those row counts by
`resume_count + 1`. `preprocessing_seconds_this_invocation` is only the latest
invocation and is never mislabeled as lifetime time; wall and optimizer time are
cumulative. Exact resume means state-complete same-runtime continuation. The
uninterrupted-versus-resumed bitwise regression is CPU-only, so CUDA bitwise
resume equivalence remains explicitly unverified. Each run also reports its own
frozen Q-scale and estimator label; the Q-at-mean comparison therefore changes
both estimator placement and its estimator-consistent denominator.

The v2 manifest has a separate `external_evaluations` interface; external
controls are never coerced into adapter training runs. `evaluate_td3bc_v1`
entries select either a raw `clean` or `persistent_action_noise` arm and lock the
raw JSON SHA, actual checkpoint and adjacent training-config SHA, transform,
scale, base training variant/action pairing/seed/update count, evaluator hashes,
and exact rollout protocol. The frozen template includes raw-linked identity,
scalar-1.2, oracle-beta inverse, and dual-action controls for base seeds 1/10.
Same-base comparisons enforce identical checkpoint SHA; dual-policy comparisons
are explicitly labeled `different_trained_policy` and lock both distinct hashes.

`channel_opex_v1` entries support the paired `arms.baseline_only` and
`arms.adapted` schema emitted by `evaluate_channel_opex.py`, including T=2. They
lock the full controller dict (baseline transform, selected step size, T, K,
model beta/calibration mode, independent gradient-noise seed, Q reducer and
trust region), base/config/calibration hashes, implementation hashes, three seed
streams, and exact Q-forward/Q-backward accounting. Because a future
confirmation JSON cannot have a predeclared content hash, freeze mode instead
requires its path to be absent; aggregation records its actual source SHA after
the non-overwriting evaluator creates it. Pre-existing TD3+BC controls do have
their content hashes locked and are fully revalidated during freeze.

The frozen template predeclares original-structure OPEX and the dev-selected
inverse- and identity-anchor CA-OPEX controls for base seeds 1/10. OPEX cost is
reported with `adapted_arm_deployment_controller_only` scope: adapted-arm
environment steps, actor rows, Q rows, backward calls, and wall time are the
deployment cost. Separate baseline-arm and paired-evaluation totals preserve
the full experimental expense. The formal rollout path is required to be absent
at freeze time; unlike already-existing TD3+BC records, its future raw SHA is
recorded by aggregation rather than guessed in advance.

All six formal OPEX runs share the gradient-noise seed block
`69300..69349`, so base seeds 1/10 use common random numbers for gradient noise
as well as the common environment/action-noise rollout cases; the beta-zero
original controller records but does not consume that stream. The manifest
predeclares, in fixed order, selected inverse-anchor CA-OPEX minus identity-
anchor CA-OPEX, minus original-structure OPEX, and minus its inverse-only arm
for base-policy checkpoint seeds 1 and 10. JSON/CSV/Markdown report each
checkpoint-level paired difference and the descriptive mean across exactly two
base-policy checkpoints. No training-seed interval is computed, and the common
50-case block is never pooled into 100 independent pipeline repetitions.

CA-OPEX development selection is locked through the v3 chronology record, its
post-evaluation provenance-amendment protocol, the preserved pre-evaluation
protocol/selector/selection, and the original-grid protocol/selector/selection.
The canonical preflight recomputes both arm means and paired differences from
each raw return vector, checks paired environment/noise seeds, and inventories
all ten candidate files by path and SHA. It also requires every candidate's full
implementation map to equal the frozen OPEX implementation, not merely the
evaluator hash. All ten candidate sources are emitted under
`freeze_provenance.verified_opex_development_candidates`.

“Confirmation” here has a deliberately narrow meaning: the frozen adapter and
CA-OPEX versions are not run or tuned on the 50 formal episodes, and base seeds
1/10 are predeclared rather than performance-screened. Some external baseline
arms on the same environment/noise seeds already exist; they are retained in
full and the protocol does not describe the entire episode block as blind.
Cross-file baseline-equivalence declarations then require elementwise identical
returns whenever checkpoint, transform semantics, and rollout seed streams say
the baseline controller is the same (including inverse sampled-vs-Q-at-mean,
identity narrow/wide/nominal, and OPEX/TD3+BC baseline paths).
