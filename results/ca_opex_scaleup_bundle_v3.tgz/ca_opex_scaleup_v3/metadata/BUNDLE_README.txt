CA-OPEX scale-up bundle v3 (canonical)
Created from /root/hubl_research_20260914 after Walker2d five-seed and
Hopper-v4 three-seed completion. This v3 includes the corrected generic
multiseed summary entry point, which reports positive seeds over the actual
training-seed count rather than a Walker-specific denominator.

Completed evidence included:
- Walker2d scaleup seeds 2, 3, 4, with raw five-arm records, checkpoints,
  stage logs, per-seed aggregates, and five-seed aggregate/verifier.
- Hopper-v4 cross-task seeds 2, 3, 4, with raw five-arm records, checkpoints,
  stage logs, per-seed aggregates, and three-seed aggregate/verifier.
- Relevant source code, configs, tests, calibration pair artifacts, dry-run
  validation, launch records, takeover verification, and full test logs.
- The preserved diagnostic quarantine from a corrected test-collection issue.

Optional beta-severity output is under results/running_optional/. It was
genuinely running when this bundle was made and is not a completed result;
partial units and chain logs are retained only for provenance/resume.

Source HDF5 datasets are not included. Their authoritative paths and SHA-256
values are recorded in aggregate/config records and research package.
Checkpoints are included: yes.
Formal v3 bundle and canonical formal aggregate are not included and were not
modified. To reproduce the combined tree, extract formal_confirmation_repro_bundle_v3.tgz
first, then the delivery overlay if needed, then this bundle; never substitute
this bundle for formal v3. For scale-up-only checks, use included code, tests,
results, and calibration artifacts directly.
